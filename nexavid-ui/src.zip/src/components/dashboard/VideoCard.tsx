"use client";
import { Card, CardMedia, CardContent, Typography, Box, Button } from "@mui/material";

interface VideoCardProps {
  title: string;
  thumbnail: string;
  createdAt: string;
}

const VideoCard = ({ title, thumbnail, createdAt }: VideoCardProps) => {
  return (
    <Card sx={{ width: "100%", borderRadius: 2, mb: 2 }}>
      <CardMedia component="img" height="160" image={thumbnail} alt={title} />
      <CardContent>
        <Typography variant="h6">{title}</Typography>
        <Typography variant="body2" color="text.secondary">
          Created: {createdAt}
        </Typography>
        <Box mt={2}>
          <Button variant="contained" color="primary" fullWidth>
            Edit Video
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default VideoCard;
