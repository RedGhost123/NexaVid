"use client";
import { useState } from "react";
import { Box, Container, Typography } from "@mui/material";
import PromptInput from "@components/ai/PromptInput";
import AvatarSelector from "@components/ai/AvatarSelector";
import LivePreview from "@components/ai/LivePreview";

export default function GenerateAI() {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [avatar, setAvatar] = useState("");

  const handleGenerate = async (prompt: string) => {
    console.log("Generating video for:", prompt, "with avatar:", avatar);
    setTimeout(() => {
      setVideoUrl("/ai_generated_demo.mp4");
    }, 3000);
  };

  return (
    <Container sx={{ mt: 6 }}>
      <Typography variant="h4" fontWeight="bold">
        AI Video Generator
      </Typography>
      <PromptInput onGenerate={handleGenerate} />
      <AvatarSelector onSelect={setAvatar} />
      <LivePreview videoUrl={videoUrl} />
    </Container>
  );
}
